import setuptools

setuptools.setup(
    name="equoai",
    version="0.0.2",
    author="David Hostler",
    description="Python client for accessing the EquoAI platform and all its core services",
    packages=["equoai"]
)